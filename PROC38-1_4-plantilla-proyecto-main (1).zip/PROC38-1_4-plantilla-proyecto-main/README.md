# PROC38-1_4-plantilla-proyecto
## Plantilla del proyecto para la clase 38 nivel PRO 1:4.
Modificación por parte del alumno de dos comentarios y cambio en la configuración Firebase de la base de datos.
Etapa 2.

### Comentarios en inglés:
CarRacingGame1.0
Car Racing Game Stage 1.0
